/*: - Copyright :  Bulldog Ventures Inc  ©  2020 */
import UIKit

/*:

- Variables

Create a variable called name and initialize it to the name of your favorite actor, singer, or sports celebrity */
var name = "Selena Gomez"
/*:
- Displaying on the screen

Display the contents of name on the screen

 Change the value of name to your name*/
var name2 = "Mehwish Tabassum"
/*:
- Constants
 
Display the contents of name

Create a constant (let instead of var) called language and initialize it to "Swift"

Display the contents of the language constant on screen

Create 3 different constants and initialize them to hold integers of your choice. Name the constants a, b, and c

Create 3 constants that are doubles (they have decimal points) Initialize them with values of your choice. Name the constants d, e, and f*/
let language = "Swift"
let a = 15

let b = 100

let c = 89

let d = 5.5

let e = 3.2

let f = 1.3
/*:
- Operators

Create an assortment of statements using the constants that you created that will perform the following actions - then display the equation and the result on the screen.*/
var add = (c + a + c + b)
var sub = (b - c - a - c)
var multi = (c * b * a * c)
var divi = (b / a / c / b)

/*:
- Add two constants
 
-                print("a + b = " ) + (a + b)

Addition sample with at least 4 constants

Subtraction sample

Division sample

Multiplication sample*/
print("\(c) + \(a) = \(add) + \(c) + \(b) = \(add)")
print("\(b) - \(c) = \(sub) - \(a) - \(c) = \(sub)")
print("\(c) * \(b) = \(multi) * \(a) * \(c) = \(multi)")
print("\(b) / \(a) = \(divi) / \(c) / \(b) = \(divi)")
/*:
- If Statements
 
Use the following constants to solve the problems :*/
 
let temperature = 90
let raining = true
let time = "Morning"

/*: Write a statement that tells someone to wear shorts if it is over 80 degrees, and jeans if it is less than 80 degrees. Check with the temperature constant

Check the raining constant and tell the user if they need an umbrella or not

Check the time constant and if it is morning tell the user to go to school, if it is afternoon tell the user to go home, and if it is night tell the user to go to bed*/
if temperature > 80{
    print("Wear shorts")
}
if temperature < 80{
    print("Wear pants")
}

if raining == true{
    print("You will need an Umbrella")
}
else{
    print("Don't take an Umbrella")
}
if time == "Morning" {
    print("Go to school")
}
else if time == "Afternoon"{
    print("Go back home")
}
else if time == "Night"{
    print("Go to sleep")
}
/*:
- Loops

Using a for loop print the numbers from 1 to 10 on screen

Using  a while loop print the numbers from 10 to 1 on screen*/
for index in (1...10){
    print(index)
}
var index = 10
while (index >= 1){
    print(index)
    index-=1
}
/*:
- Collections

Create an array that holds five strings

Create a tuple that holds two strings

Using a loop, step through one of the collections you created and print all of the items to the screen*/
var favDrinks:[String] = ["Coke", "Sprite","Fanta","Carrot Juice","Water"]
var sweets:[String] = ["Cake", "cakePops"]

for item in favDrinks {
    print(item)
}
for item in sweets{
    print(item)
    
}

/*:
- Functions

Create a function that takes two doubles, multiplies them, and returns the result.

Call the function, save the result in the variable "answer". Pass it two of the constants you  creataed (a, b, c, d, e, or f)*/
func multiply(Num4: Int, Num5: Int) -> Int{
    return Num4 * Num5
}
print(multiply(Num4: Int(4.5), Num5: Int(6.2)))

/*:
- Closures

Create a closure that subtracts one number from another and prints the results, use the closure. You may pass it constants or numbers*/
var Sub = {(Num1: Int, Num2: Int) -> Int in
    return Num1 - Num2
}
let difference = Sub(80,40)
print(difference)
/*:
- Enums
 
Create an enum that holds the first name of everyone in your group

Create a switch statement based on the enum that will display the birthday of the
selected person

Test it by using your own name*/
enum FirstName {
    case Mehwish
    case Ivy
    case Etornam
    case Mariyah
    case Marwa
}
var displayBirthday = FirstName.Mehwish

switch displayBirthday {

case .Mehwish:
    print ("Feburary 13th")
    
case .Ivy:
    print ("December 16th")
case .Etornam:
    print ("November 11th")
case .Mariyah:
    print ("April 10th")
case .Marwa:
    print ("January 2nd")

}
/*:
- Structure
 
Create a structure called Name that holds a first, middle, and last name and prints them on screen in one line with spaces between them

Create an instance of the Name structure, pass it your name, and use the instance you created to print your  name to the screen*/
struct Name {
    var firstName : String
    var lastName : String
}
var nameStructure = Name (firstName:"Mehwish", lastName: "Tabassum")
print(nameStructure.firstName)
print(nameStructure.lastName)

/*:
- Class
 
Create a class called Coffee that accepts size, caffineated,  cream,  and sugar then prints the order on screen

Create an instance of the class

Use the instance of the class and call the function*/
class coffee {
    var size: String = "large"
    var caffinated: Bool = true
    var cream: Bool = true
    var sugar: Bool = true
}

var drink: coffee
 
